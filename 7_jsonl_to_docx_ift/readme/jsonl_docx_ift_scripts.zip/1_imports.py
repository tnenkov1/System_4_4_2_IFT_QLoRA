import os
import json
from datetime import datetime
from docx import Document
from docx.shared import Pt
from tqdm import tqdm