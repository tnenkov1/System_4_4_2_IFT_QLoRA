import os
import json
import requests
from datetime import datetime
from tqdm import tqdm
from docx import Document