# Write manually the file names
FILES_TO_MERGE = [
    "test_dataset_l.jsonl",
    "test_dataset_u.jsonl",
    "test_dataset_w.jsonl"
]