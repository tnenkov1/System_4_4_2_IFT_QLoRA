SCRIPT_DIR = Path(__file__).resolve().parent
LISTS_DIR = SCRIPT_DIR / "file_lists"

LISTS_DIR.mkdir(exist_ok=True)