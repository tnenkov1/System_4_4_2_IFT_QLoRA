import os
import json
from datetime import datetime
from docx import Document
from tqdm import tqdm